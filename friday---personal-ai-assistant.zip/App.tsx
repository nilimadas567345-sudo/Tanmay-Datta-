import React, { useState, useRef, useEffect, useCallback } from 'react';
import { AppMode, ChatMessage, MessageType, Sender, OfflineModel, UserSettings, GeneratedImage } from './types';
import { GeminiService, STARTUP_MESSAGE, fileToBase64, getMimeType } from './services/geminiService';
import { OFFLINE_MODELS } from './services/offlineModels';
import { UserService, AppState } from './services/userService';

// --- Web Speech API Types ---
interface SpeechRecognitionErrorEvent extends Event { readonly error: string; }
interface SpeechRecognitionEvent extends Event { readonly results: SpeechRecognitionResultList; }
interface SpeechRecognition extends EventTarget {
  continuous: boolean; interimResults: boolean; lang: string;
  start(): void; stop(): void;
  onstart: (() => void) | null; onend: (() => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
}
declare global { interface Window { SpeechRecognition: any; webkitSpeechRecognition: any; } }

// --- ICONS ---
const Icons = {
  GeminiStar: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" fill="url(#gemini_grad)" />
      <defs>
        <linearGradient id="gemini_grad" x1="2" y1="2" x2="22" y2="22" gradientUnits="userSpaceOnUse">
          <stop stopColor="#4285F4" />
          <stop offset="0.5" stopColor="#9B72CB" />
          <stop offset="1" stopColor="#D96570" />
        </linearGradient>
      </defs>
    </svg>
  ),
  User: () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
  Settings: () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1-2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
  Paperclip: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.59a2 2 0 0 1-2.83-2.83l8.49-8.48" /></svg>,
  Mic: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" /><path d="M19 10v2a7 7 0 0 1-14 0v-2" /><line x1="12" y1="19" x2="12" y2="23" /><line x1="8" y1="23" x2="16" y2="23" /></svg>,
  Send: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13" /><polygon points="22 2 15 22 11 13 2 9 22 2" /></svg>,
  History: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/></svg>,
  Close: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>,
  Brain: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96.44 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 4.44-2.54Z"/><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-4.44-2.54Z"/></svg>,
  Edit: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>,
  Summarize: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="21" y1="6" x2="3" y2="6"/><line x1="21" y1="12" x2="3" y2="12"/><line x1="21" y1="18" x2="3" y2="18"/><path d="M3 10l3 2-3 2V10z"/></svg>,
  Download: () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>,
  Check: () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>,
};

// --- COMPONENTS ---

const Header: React.FC<{
  onOpenSettings: () => void;
  onOpenModelHub: () => void;
  isOffline: boolean;
  currentMode: AppMode;
  onModeChange: (mode: AppMode) => void;
}> = ({ onOpenSettings, onOpenModelHub, isOffline, currentMode, onModeChange }) => (
  <header className="fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 z-40 bg-white/80 dark:bg-[#131314]/80 backdrop-blur-md border-b dark:border-gray-800">
    <div className="flex items-center gap-2">
      <Icons.GeminiStar />
      <span className="text-xl font-medium text-gray-800 dark:text-gray-200">Friday</span>
      <div className="bg-blue-100 dark:bg-blue-900/30 text-[10px] px-2 py-0.5 rounded-full uppercase font-bold text-blue-600 dark:text-blue-400">
        {isOffline ? 'Offline' : 'Live'}
      </div>
    </div>
    <div className="flex items-center gap-2">
      <div className="hidden md:flex bg-gray-100 dark:bg-gray-800 rounded-full p-1 mr-2">
        {Object.values(AppMode).map(mode => (
          <button
            key={mode}
            onClick={() => onModeChange(mode)}
            className={`px-3 py-1 text-xs rounded-full transition-all ${currentMode === mode ? 'bg-white dark:bg-gray-700 shadow-sm text-blue-600 dark:text-blue-400' : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'}`}
          >
            {mode}
          </button>
        ))}
      </div>
      <button onClick={onOpenModelHub} className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors relative">
        <Icons.Download />
      </button>
      <button onClick={onOpenSettings} className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
        <Icons.Settings />
      </button>
    </div>
  </header>
);

const SuggestionCard: React.FC<{ icon: React.ReactNode; text: string; onClick: () => void }> = ({ icon, text, onClick }) => (
  <button 
    onClick={onClick}
    className="bg-gray-50 dark:bg-[#1e1f20] p-4 rounded-xl flex flex-col gap-3 items-start text-left border border-transparent hover:border-blue-500 transition-all group w-44 min-w-[176px] shadow-sm"
  >
    <div className="text-blue-500 dark:text-blue-400 group-hover:scale-110 transition-transform">{icon}</div>
    <p className="text-sm text-gray-700 dark:text-gray-300 font-medium line-clamp-2">{text}</p>
  </button>
);

const LandingState: React.FC<{ onSuggest: (text: string) => void }> = ({ onSuggest }) => (
  <div className="flex-1 flex flex-col items-center justify-center px-6 pt-20 pb-40 animate-fade-in">
    <h1 className="text-4xl md:text-5xl font-semibold mb-8 text-center gemini-gradient">
      Hello, Friday.
    </h1>
    <p className="text-xl text-gray-500 dark:text-gray-400 mb-12 text-center max-w-lg">
      How can I help you today?
    </p>
    <div className="flex gap-4 overflow-x-auto w-full max-w-3xl pb-4 scrollbar-hide no-scrollbar">
      <SuggestionCard 
        icon={<Icons.Brain />} 
        text="Brainstorm creative ideas for a project" 
        onClick={() => onSuggest("I need creative ideas for a 10-year anniversary celebration.")}
      />
      <SuggestionCard 
        icon={<Icons.Edit />} 
        text="Help me write a professional email" 
        onClick={() => onSuggest("Write a polite email asking for a meeting with a client.")}
      />
      <SuggestionCard 
        icon={<Icons.Summarize />} 
        text="Summarize a long article or document" 
        onClick={() => onSuggest("Can you summarize the core benefits of quantum computing?")}
      />
      <SuggestionCard 
        icon={<Icons.Mic />} 
        text="Practice a mock interview for tech" 
        onClick={() => onSuggest("Let's do a mock interview for a Senior React role.")}
      />
    </div>
  </div>
);

const MessageItem: React.FC<{ message: ChatMessage }> = ({ message }) => {
  const isUser = message.sender === Sender.User;
  
  if (message.type === MessageType.Loading) {
    return (
      <div className="flex gap-4 p-6 animate-pulse">
        <div className="mt-1"><Icons.GeminiStar /></div>
        <div className="flex-1">
          <div className="h-4 bg-gray-200 dark:bg-gray-800 rounded w-1/4 mb-2"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-800 rounded w-3/4"></div>
        </div>
      </div>
    );
  }

  return (
    <div className={`flex gap-4 p-6 message-appear ${isUser ? 'bg-transparent' : ''}`}>
      <div className="mt-1 flex-shrink-0">
        {isUser ? (
          <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white text-xs font-bold">U</div>
        ) : (
          <Icons.GeminiStar />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-gray-800 dark:text-gray-200 text-[16px] leading-relaxed whitespace-pre-wrap break-words">
          {message.imageUrl && <img src={message.imageUrl} className="max-w-md w-full rounded-xl mb-4 border dark:border-gray-700 shadow-md" alt="Generated" />}
          {message.text}
        </div>
        {message.citations && message.citations.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {message.citations.map((c, i) => (
              <a key={i} href={c.uri} target="_blank" rel="noopener noreferrer" className="text-xs bg-gray-100 dark:bg-gray-800 text-blue-600 dark:text-blue-400 px-3 py-1 rounded-full hover:underline border dark:border-gray-700 transition-colors">
                {c.title}
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// --- APP COMPONENT ---

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(UserService.loadState);
  const [currentMode, setCurrentMode] = useState<AppMode>(AppMode.Chat);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [isListening, setIsListening] = useState(false);
  const [isModelHubOpen, setIsModelHubOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [downloadingStatus, setDownloadingStatus] = useState<Record<string, number>>({});

  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const { settings, chatHistory, downloadedModels: downloadedModelIds } = appState;
  const downloadedModels = new Set(downloadedModelIds);

  useEffect(() => { UserService.saveState(appState); }, [appState]);
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => { window.removeEventListener('online', handleOnline); window.removeEventListener('offline', handleOffline); }
  }, []);

  const addMessage = useCallback((message: Omit<ChatMessage, 'id' | 'timestamp'>) => {
    const newMessage = {
      ...message,
      id: `msg-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setAppState(prev => ({ ...prev, chatHistory: [...prev.chatHistory, newMessage] }));
  }, []);

  const handleSend = async (text: string, file?: File) => {
    if (!text && !file) return;
    setInputText('');
    setAttachedFile(null);
    addMessage({ sender: Sender.User, type: MessageType.Text, text });
    setIsLoading(true);

    const effectiveOffline = isOffline || settings.forceOffline;

    try {
      if (effectiveOffline) {
        const model = OFFLINE_MODELS.find(m => m.category === currentMode);
        if (model && downloadedModels.has(model.id)) {
          setTimeout(() => {
            addMessage({ sender: Sender.AI, type: MessageType.Text, text: `(Offline Mode: ${model.name})\n\nThis is an offline response simulation. In a production environment, Friday would use the pre-downloaded weight files to generate this text locally on your device.` });
            setIsLoading(false);
          }, 1200);
          return;
        } else {
          throw new Error(`Offline mode requires the ${currentMode} model to be downloaded first in the Model Hub.`);
        }
      }

      let response;
      switch (currentMode) {
        case AppMode.Chat:
        case AppMode.Audio:
        case AppMode.Task:
          response = await GeminiService.generateChatResponse(text, currentMode);
          addMessage({ sender: Sender.AI, type: MessageType.Text, text: response });
          break;
        case AppMode.Search:
          const sResp = await GeminiService.generateSearchResponse(text);
          addMessage({ sender: Sender.AI, type: MessageType.Text, text: sResp.text, citations: sResp.citations });
          break;
        case AppMode.ImageGen:
          let imgB64, mime;
          if (file) { imgB64 = await fileToBase64(file); mime = getMimeType(file); }
          response = await GeminiService.generateImage(text, imgB64, mime);
          addMessage({ sender: Sender.AI, type: MessageType.Image, text: `Generated: ${text}`, imageUrl: response });
          break;
        case AppMode.ImageAnalysis:
          if (!file) throw new Error("Image required for analysis.");
          const b64 = await fileToBase64(file);
          const m = getMimeType(file);
          response = await GeminiService.analyzeImage(text, b64, m);
          addMessage({ sender: Sender.AI, type: MessageType.Text, text: response });
          break;
      }
    } catch (e) {
      addMessage({ sender: Sender.AI, type: MessageType.Error, text: (e as Error).message });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadModel = (modelId: string) => {
    if (downloadedModels.has(modelId) || downloadingStatus[modelId] !== undefined) return;

    setDownloadingStatus(prev => ({ ...prev, [modelId]: 0 }));
    
    // Simulate varying speeds based on "file size"
    const model = OFFLINE_MODELS.find(m => m.id === modelId);
    const step = model ? Math.max(2, 10 - parseInt(model.size) / 30) : 5;

    const interval = setInterval(() => {
      setDownloadingStatus(prev => {
        const current = prev[modelId] || 0;
        if (current >= 100) {
          clearInterval(interval);
          setAppState(s => ({ ...s, downloadedModels: [...s.downloadedModels, modelId] }));
          const next = { ...prev };
          delete next[modelId];
          return next;
        }
        return { ...prev, [modelId]: current + step };
      });
    }, 200);
  };

  const startListening = () => {
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) return;
    recognitionRef.current = new SpeechRec();
    recognitionRef.current.onstart = () => setIsListening(true);
    recognitionRef.current.onend = () => setIsListening(false);
    recognitionRef.current.onresult = (e: any) => setInputText(e.results[0][0].transcript);
    recognitionRef.current.start();
  };

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [chatHistory, isLoading]);

  return (
    <div className="flex flex-col h-screen bg-white dark:bg-[#131314] transition-colors overflow-hidden">
      <Header 
        onOpenSettings={() => setIsSettingsOpen(true)} 
        onOpenModelHub={() => setIsModelHubOpen(true)}
        isOffline={isOffline || settings.forceOffline}
        currentMode={currentMode}
        onModeChange={setCurrentMode}
      />

      <main ref={scrollRef} className="flex-1 overflow-y-auto overflow-x-hidden pt-16 pb-32">
        {chatHistory.length <= 1 && !isLoading ? (
          <LandingState onSuggest={(t) => handleSend(t)} />
        ) : (
          <div className="max-w-3xl mx-auto w-full">
            {chatHistory.map(m => <MessageItem key={m.id} message={m} />)}
            {isLoading && <MessageItem message={{ id: 'l', sender: Sender.AI, type: MessageType.Loading, text: '', timestamp: '' }} />}
          </div>
        )}
      </main>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-white dark:from-[#131314] via-white/90 dark:via-[#131314]/90 to-transparent">
        <div className="max-w-3xl mx-auto">
          {attachedFile && (
            <div className="mb-2 p-2 bg-gray-50 dark:bg-gray-800 border dark:border-gray-700 rounded-xl flex items-center justify-between shadow-sm animate-fade-in">
              <div className="flex items-center gap-2 truncate">
                 <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/30 rounded flex items-center justify-center text-blue-500">
                    <Icons.Paperclip />
                 </div>
                 <span className="text-xs font-medium truncate max-w-[200px] text-gray-700 dark:text-gray-300">{attachedFile.name}</span>
              </div>
              <button onClick={() => setAttachedFile(null)} className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition-colors"><Icons.Close /></button>
            </div>
          )}
          <div className={`relative flex items-center bg-gray-100 dark:bg-[#1e1f20] rounded-[32px] px-6 py-3 transition-all shadow-sm focus-within:shadow-md border border-transparent focus-within:border-gray-200 dark:focus-within:border-gray-700 ${isListening ? 'ring-2 ring-blue-500' : ''}`}>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="text-gray-500 dark:text-gray-400 hover:text-blue-500 p-1 transition-colors"
              title="Attach File"
            >
              <Icons.Paperclip />
            </button>
            <input 
              type="file" ref={fileInputRef} className="hidden" 
              onChange={(e) => e.target.files?.[0] && setAttachedFile(e.target.files[0])} 
            />
            <input 
              type="text" 
              placeholder={isListening ? "Listening..." : "Enter a prompt here"}
              className="flex-1 bg-transparent border-none outline-none px-4 text-gray-800 dark:text-gray-200 placeholder-gray-500"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend(inputText, attachedFile || undefined)}
            />
            <div className="flex items-center gap-2">
              <button 
                onClick={isListening ? () => recognitionRef.current?.stop() : startListening}
                className={`p-1 transition-colors ${isListening ? 'text-red-500 animate-pulse' : 'text-gray-500 dark:text-gray-400 hover:text-blue-500'}`}
              >
                <Icons.Mic />
              </button>
              {(inputText.trim() || attachedFile) && (
                <button 
                  onClick={() => handleSend(inputText, attachedFile || undefined)}
                  className="p-1 text-blue-500 hover:scale-110 transition-transform"
                >
                  <Icons.Send />
                </button>
              )}
            </div>
          </div>
          <p className="text-[10px] text-center text-gray-400 mt-4 uppercase tracking-widest font-medium opacity-70">
            Friday can make mistakes. Check important info.
          </p>
        </div>
      </div>

      {/* Settings Modal */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm animate-fade-in" onClick={() => setIsSettingsOpen(false)}>
           <div className="bg-white dark:bg-[#1e1f20] rounded-[28px] p-8 w-full max-w-md shadow-2xl border dark:border-gray-800" onClick={e => e.stopPropagation()}>
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-2xl font-semibold">Settings</h2>
                <button onClick={() => setIsSettingsOpen(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full"><Icons.Close /></button>
              </div>
              <div className="space-y-6">
                 <div className="flex justify-between items-center group">
                    <div>
                       <p className="font-medium">Dark Mode</p>
                       <p className="text-xs text-gray-500">Switch between light and dark themes</p>
                    </div>
                    <button 
                      onClick={() => setAppState(p => ({...p, settings: {...p.settings, theme: p.settings.theme === 'dark' ? 'light' : 'dark'}}))} 
                      className={`w-12 h-6 rounded-full transition-colors relative ${settings.theme === 'dark' ? 'bg-blue-600' : 'bg-gray-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${settings.theme === 'dark' ? 'left-7' : 'left-1'}`} />
                    </button>
                 </div>
                 <div className="flex justify-between items-center group">
                    <div>
                       <p className="font-medium">Force Offline</p>
                       <p className="text-xs text-gray-500">Always use local models even when online</p>
                    </div>
                    <button 
                      onClick={() => setAppState(p => ({...p, settings: {...p.settings, forceOffline: !p.settings.forceOffline}}))} 
                      className={`w-12 h-6 rounded-full transition-colors relative ${settings.forceOffline ? 'bg-blue-600' : 'bg-gray-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${settings.forceOffline ? 'left-7' : 'left-1'}`} />
                    </button>
                 </div>
                 <div className="pt-6 border-t dark:border-gray-800">
                    <button onClick={() => { setAppState(p => ({...p, chatHistory: [STARTUP_MESSAGE]})); setIsSettingsOpen(false); }} className="w-full py-3 bg-red-500/10 text-red-500 font-medium rounded-xl hover:bg-red-500/20 transition-colors">
                      Clear Conversations
                    </button>
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* Model Hub Modal */}
      {isModelHubOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm animate-fade-in" onClick={() => setIsModelHubOpen(false)}>
          <div className="bg-white dark:bg-[#1e1f20] rounded-[28px] p-8 w-full max-w-2xl h-[85vh] overflow-y-auto shadow-2xl border dark:border-gray-800" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-start mb-8">
              <div>
                <h2 className="text-2xl font-semibold mb-1">Model Hub</h2>
                <p className="text-sm text-gray-500">Download models for offline AI capabilities</p>
              </div>
              <button onClick={() => setIsModelHubOpen(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full"><Icons.Close /></button>
            </div>
            
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-2xl mb-8 flex items-center justify-between">
               <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 dark:bg-blue-800 rounded-full text-blue-600 dark:text-blue-400">
                    <Icons.Download />
                  </div>
                  <div>
                    <p className="text-xs font-bold uppercase text-blue-600 dark:text-blue-400">Available Storage</p>
                    <p className="text-lg font-bold text-gray-800 dark:text-gray-100">12.4 GB Free</p>
                  </div>
               </div>
               <div className="text-right">
                  <p className="text-xs text-gray-500">Offline Status</p>
                  <p className={`text-sm font-medium ${downloadedModels.size > 0 ? 'text-green-500' : 'text-orange-500'}`}>
                    {downloadedModels.size > 0 ? `${downloadedModels.size} Models Loaded` : 'Cloud Only'}
                  </p>
               </div>
            </div>

            <div className="space-y-4">
              {OFFLINE_MODELS.map(m => {
                const isDownloaded = downloadedModels.has(m.id);
                const progress = downloadingStatus[m.id];
                const isDownloading = progress !== undefined;

                return (
                  <div key={m.id} className="p-5 border dark:border-gray-800 rounded-2xl flex flex-col md:flex-row gap-4 items-start md:items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                     <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-bold text-gray-800 dark:text-gray-100">{m.name}</h3>
                          {m.isRecommended && <span className="bg-green-100 dark:bg-green-900/30 text-[10px] text-green-600 px-2 py-0.5 rounded-full font-bold">Recommended</span>}
                        </div>
                        <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-1">{m.description}</p>
                        <div className="flex items-center gap-3 mt-2 text-[10px] text-gray-400 font-bold uppercase">
                           <span>{m.size}</span>
                           <span>•</span>
                           <span>{m.category}</span>
                        </div>
                     </div>
                     
                     <div className="w-full md:w-auto">
                        {isDownloaded ? (
                          <div className="flex items-center gap-2 text-green-500 bg-green-50 dark:bg-green-900/20 px-4 py-2 rounded-full border border-green-200 dark:border-green-800/30">
                            <Icons.Check />
                            <span className="text-sm font-bold">Installed</span>
                          </div>
                        ) : isDownloading ? (
                          <div className="w-full md:w-40">
                             <div className="flex justify-between text-[10px] font-bold mb-1">
                                <span className="text-blue-500">Downloading...</span>
                                <span>{Math.round(progress)}%</span>
                             </div>
                             <div className="w-full h-1.5 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                                <div className="h-full bg-blue-500 transition-all duration-300" style={{ width: `${progress}%` }} />
                             </div>
                          </div>
                        ) : (
                          <button 
                            onClick={() => handleDownloadModel(m.id)} 
                            className="w-full md:w-auto bg-gray-900 dark:bg-white text-white dark:text-black px-6 py-2 rounded-full text-sm font-bold flex items-center justify-center gap-2 hover:scale-105 active:scale-95 transition-transform"
                          >
                            <Icons.Download />
                            Download
                          </button>
                        )}
                     </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;