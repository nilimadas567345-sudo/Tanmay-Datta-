
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { AppMode, ChatMessage, MessageType, Sender, OfflineModel, UserSettings, GeneratedImage } from './types';
import { GeminiService, STARTUP_MESSAGE, fileToBase64, getMimeType } from './services/geminiService';
import { OFFLINE_MODELS } from './services/offlineModels';
import { UserService, AppState } from './services/userService';

// --- FIX: Add type definitions for Web Speech API ---
// The Web Speech API is not part of the standard DOM typings for TypeScript,
// so we need to declare the interfaces and extend the Window object.

interface SpeechRecognitionErrorEvent extends Event {
  readonly error: string;
  readonly message: string;
}

interface SpeechRecognitionEvent extends Event {
  readonly resultIndex: number;
  readonly results: SpeechRecognitionResultList;
}

interface SpeechRecognitionResultList {
  readonly length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionResult {
  readonly isFinal: boolean;
  readonly length: number;
  item(index: number): SpeechRecognitionAlternative;
  [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionAlternative {
  readonly transcript: string;
  readonly confidence: number;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onstart: (() => void) | null;
  onend: (() => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
}

interface SpeechRecognitionStatic {
    new(): SpeechRecognition;
}

declare global {
  interface Window {
    SpeechRecognition: SpeechRecognitionStatic;
    webkitSpeechRecognition: SpeechRecognitionStatic;
  }
}

// --- ICONS --- //
const Icons = {
  Menu: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="1" /><circle cx="12" cy="5" r="1" /><circle cx="12" cy="19" r="1" /></svg>,
  Paperclip: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.59a2 2 0 0 1-2.83-2.83l8.49-8.48" /></svg>,
  Send: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13" /><polygon points="22 2 15 22 11 13 2 9 22 2" /></svg>,
  Mic: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" /><path d="M19 10v2a7 7 0 0 1-14 0v-2" /><line x1="12" y1="19" x2="12" y2="23" /><line x1="8" y1="23" x2="16" y2="23" /></svg>,
  Chat: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></svg>,
  Search: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>,
  Image: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2" /><circle cx="8.5" cy="8.5" r="1.5" /><polyline points="21 15 16 10 5 21" /></svg>,
  Analyze: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></svg>,
  Plus: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>,
  Close: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>,
  ModelHub: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"/><path d="M12 12v9"/><path d="m8 17 4 4 4-4"/></svg>,
  Sun: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>,
  Moon: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>,
  Settings: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>,
  ClearChat: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>,
  ExportChat: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>,
  Task: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path><rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect><path d="m9 14 2 2 4-4"></path></svg>,
  Gallery: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>,
  Trash: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>,
  Download: () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>,
};


// --- UI COMPONENTS --- //

interface HeaderProps {
    mode: AppMode;
    isOffline: boolean;
    theme: 'light' | 'dark';
    toggleTheme: () => void;
    onMenuClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ mode, isOffline, theme, toggleTheme, onMenuClick }) => (
  <header className="bg-[#005E54] dark:bg-[#202C33] text-white p-3 flex justify-between items-center shadow-md fixed top-0 left-0 right-0 z-20">
    <div className="flex items-center">
      <div className="w-10 h-10 mr-3 bg-white/10 rounded-full flex items-center justify-center">
          <Icons.Chat />
      </div>
      <div>
        <h1 className="text-lg font-semibold">Friday</h1>
        <div className="flex items-center space-x-2">
          <p className="text-xs opacity-80">{mode}</p>
          <div className={`w-2 h-2 rounded-full ${isOffline ? 'bg-red-500' : 'bg-green-500'}`} title={isOffline ? 'Offline' : 'Online'}></div>
        </div>
      </div>
    </div>
    <div className="flex items-center">
      <button onClick={toggleTheme} className="p-2 mr-2" aria-label="Toggle Theme">
        {theme === 'light' ? <Icons.Moon /> : <Icons.Sun />}
      </button>
      <button onClick={onMenuClick} className="p-2" aria-label="Menu"><Icons.Menu /></button>
    </div>
  </header>
);

const ChatBubble: React.FC<{ message: ChatMessage }> = ({ message }) => {
  const isUser = message.sender === Sender.User;
  const bubbleClasses = isUser
    ? 'bg-[#DCF8C6] dark:bg-[#005C4B] self-end'
    : 'bg-white dark:bg-[#202C33] self-start';
  const containerClasses = isUser ? 'justify-end' : 'justify-start';

  if (message.type === MessageType.Loading) {
    return (
      <div className={`flex ${containerClasses} mb-2`}>
        <div className="bg-white dark:bg-[#202C33] p-2 rounded-lg flex items-center space-x-2 animate-pulse">
          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-75"></div>
          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-150"></div>
          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-300"></div>
          <span className="text-sm text-gray-500 dark:text-gray-400">Friday is typing...</span>
        </div>
      </div>
    );
  }
  
  return (
    <div className={`flex ${containerClasses} mb-2 animate-fade-in`}>
      <div className={`p-2 rounded-lg max-w-sm md:max-w-md lg:max-w-lg ${bubbleClasses}`}>
        {message.type === MessageType.Image && message.imageUrl && (
          <img src={message.imageUrl} alt="Generated" className="rounded-md mb-2 max-w-xs" />
        )}
        {message.type === MessageType.Error ? (
           <p className="text-red-500 dark:text-red-400 whitespace-pre-wrap">{message.text}</p>
        ) : (
           <p className="text-gray-800 dark:text-gray-200 whitespace-pre-wrap">{message.text}</p>
        )}
        {message.citations && message.citations.length > 0 && (
          <div className="mt-2 border-t border-gray-200 dark:border-gray-700 pt-2">
            <h4 className="text-xs font-bold text-gray-600 dark:text-gray-400 mb-1">Sources:</h4>
            <ul className="text-xs list-disc pl-4">
              {message.citations.map((cite, index) => (
                <li key={index}>
                  <a href={cite.uri} target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline">
                    {cite.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}
        <div className="text-right text-xs text-gray-500 dark:text-gray-400 mt-1">{message.timestamp}</div>
      </div>
    </div>
  );
};

const ChatWindow: React.FC<{ messages: ChatMessage[] }> = ({ messages }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 pt-20 pb-24">
      {messages.map(msg => <ChatBubble key={msg.id} message={msg} />)}
    </div>
  );
};

interface MessageInputProps {
    onSend: (text: string, file?: File) => void;
    mode: AppMode;
    isLoading: boolean;
    isListening: boolean;
    onStartListening: () => void;
    onStopListening: () => void;
    setText: (text: string) => void;
    text: string;
}

const MessageInput: React.FC<MessageInputProps> = ({ onSend, mode, isLoading, isListening, onStartListening, onStopListening, text, setText }) => {
    const [file, setFile] = useState<File | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    
    // Logic for tap vs hold interaction
    const interactionStartRef = useRef<number>(0);
    const initiatedByPressRef = useRef<boolean>(false);

    const handleSend = () => {
        if ((text.trim() || file) && !isLoading) {
            onSend(text.trim(), file || undefined);
            setText('');
            setFile(null);
            if(fileInputRef.current) fileInputRef.current.value = '';
        }
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
        }
    };
    
    useEffect(() => {
        setFile(null);
        if(fileInputRef.current) fileInputRef.current.value = '';
    }, [mode])
    
    // --- Microphone Button Handlers ---
    const handleMicDown = (e: React.PointerEvent) => {
        e.preventDefault(); // Prevent text selection/context menu
        // If we are not listening, we start listening on press (Potential Hold start).
        if (!isListening) {
            onStartListening();
            initiatedByPressRef.current = true;
            interactionStartRef.current = Date.now();
        } else {
             // If we are already listening, this press implies a "stop" action is coming up (likely a tap to stop).
             // We don't stop immediately on down, we wait for up.
             initiatedByPressRef.current = false;
        }
    };

    const handleMicUp = (e: React.PointerEvent) => {
        e.preventDefault();
        
        if (initiatedByPressRef.current) {
            // We started the listening session on this press sequence.
            const duration = Date.now() - interactionStartRef.current;
            if (duration > 500) {
                // It was a long press (hold), so we stop on release.
                onStopListening();
            }
            // If it was a short press (tap), we do nothing here, allowing it to stay ON (Toggle ON).
        } else {
            // We didn't start it on this press (it was already listening).
            // This means the user tapped to stop.
            onStopListening();
        }
        initiatedByPressRef.current = false;
    };
    
    // If finger leaves the button while holding, stop listening
    const handleMicLeave = (e: React.PointerEvent) => {
       if (isListening && initiatedByPressRef.current) {
            const duration = Date.now() - interactionStartRef.current;
            if (duration > 500) {
                onStopListening();
            }
       }
    };


    const placeholderText = {
        [AppMode.Chat]: "Type a message...",
        [AppMode.Search]: "Search the web...",
        [AppMode.ImageGen]: "Describe image or upload to edit...",
        [AppMode.ImageAnalysis]: "Describe the image or ask a question...",
        [AppMode.Audio]: isListening ? "Listening..." : "Speak or type...",
        [AppMode.Task]: "Describe your complex task...",
    }[mode];

    const canSend = text.trim() || file;
    const showMic = mode === AppMode.Audio && !canSend;
    const showAttachment = mode === AppMode.ImageAnalysis || mode === AppMode.ImageGen;

    return (
        <div className="bg-gray-100 dark:bg-[#111B21] p-2 fixed bottom-0 left-0 right-0 z-20 max-w-4xl mx-auto">
             {file && (
                <div className="p-2 bg-gray-200 dark:bg-[#202C33] rounded-t-lg flex items-center justify-between">
                    <div className="flex items-center gap-2 text-gray-800 dark:text-gray-200">
                        <Icons.Image/>
                        <span className="text-sm font-medium">{file.name}</span>
                    </div>
                    <button onClick={() => setFile(null)} className="p-1 rounded-full hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200">
                        <Icons.Close/>
                    </button>
                </div>
            )}
            <div className="flex items-center bg-white dark:bg-[#202C33] rounded-lg p-2 shadow-sm">
                <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
                {showAttachment && (
                    <button onClick={() => fileInputRef.current?.click()} className="text-gray-500 dark:text-gray-400 p-2 hover:text-gray-700 dark:hover:text-gray-200">
                        <Icons.Paperclip />
                    </button>
                )}
                <input
                    type="text"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                    placeholder={placeholderText}
                    className="flex-1 bg-transparent border-none focus:outline-none px-3 text-gray-800 dark:text-gray-200"
                    disabled={isLoading || isListening}
                />
                <button
                    onPointerDown={showMic ? handleMicDown : undefined}
                    onPointerUp={showMic ? handleMicUp : undefined}
                    onPointerLeave={showMic ? handleMicLeave : undefined}
                    onClick={canSend ? handleSend : undefined}
                    disabled={isLoading || (!canSend && !showMic)}
                    className={`bg-[#128C7E] text-white rounded-full w-12 h-10 flex items-center justify-center hover:bg-[#075E54] disabled:bg-gray-400 disabled:cursor-not-allowed transition-transform duration-150 transform active:scale-95 ${isListening ? 'bg-red-500 mic-pulse' : ''} touch-none select-none`}
                    style={{ touchAction: 'none' }}
                >
                    {canSend ? <Icons.Send /> : <Icons.Mic />}
                </button>
            </div>
        </div>
    );
};


interface ModeSelectorProps {
  currentMode: AppMode;
  onModeChange: (mode: AppMode) => void;
  isOffline: boolean;
  downloadedModels: Set<string>;
}

const ModeSelector: React.FC<ModeSelectorProps> = ({ currentMode, onModeChange, isOffline, downloadedModels }) => {
  const [isOpen, setIsOpen] = useState(false);

  const getModelForMode = (mode: AppMode) => OFFLINE_MODELS.find(m => m.category === mode);

  const modes = [
    { mode: AppMode.Chat, icon: <Icons.Chat />, label: "Chat" },
    { mode: AppMode.Search, icon: <Icons.Search />, label: "Search" },
    { mode: AppMode.ImageGen, icon: <Icons.Image />, label: "Generate" },
    { mode: AppMode.ImageAnalysis, icon: <Icons.Analyze />, label: "Analyze" },
    { mode: AppMode.Audio, icon: <Icons.Mic />, label: "Audio" },
    { mode: AppMode.Task, icon: <Icons.Task />, label: "Tasks" },
  ];

  const handleSelectMode = (mode: AppMode) => {
    onModeChange(mode);
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-24 right-4 z-30">
        <div className={`flex flex-col items-center space-y-3 transition-all duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          {modes.map(({mode, icon, label}) => {
              const model = getModelForMode(mode);
              const isOnlineOnly = mode === AppMode.Search;
              const isEnabled = !isOffline || isOnlineOnly ? !isOffline : (model ? downloadedModels.has(model.id) : false);

              return (
              <div key={mode} className="flex items-center space-x-2" title={!isEnabled ? 'Requires internet or a downloaded offline model' : ''}>
                   <div className="bg-white dark:bg-[#2A3942] text-gray-700 dark:text-gray-200 text-sm px-3 py-1 rounded-md shadow-lg">{label}</div>
                   <button
                       onClick={() => handleSelectMode(mode)}
                       disabled={!isEnabled}
                       className={`w-12 h-12 rounded-full shadow-lg flex items-center justify-center transition-colors ${currentMode === mode ? 'bg-emerald-500 text-white' : 'bg-white dark:bg-[#2A3942] text-gray-600 dark:text-gray-300'} ${!isEnabled ? 'opacity-50 cursor-not-allowed' : ''}`}>
                       {icon}
                   </button>
              </div>
          )})}
        </div>
        <button
            onClick={() => setIsOpen(!isOpen)}
            className="w-16 h-16 bg-[#25D366] text-white rounded-full shadow-xl flex items-center justify-center mt-4 transition-transform duration-300 hover:scale-105 active:scale-95">
           {isOpen ? <Icons.Close/> : <Icons.Plus/>}
        </button>
    </div>
  );
};

const ProgressBar: React.FC<{ progress: number }> = ({ progress }) => (
    <div className="w-full bg-gray-200 rounded-full h-1.5 dark:bg-gray-700 my-1">
        <div className="bg-blue-600 h-1.5 rounded-full" style={{ width: `${progress}%` }}></div>
    </div>
);

const ModelCard: React.FC<{
    model: OfflineModel;
    isDownloaded: boolean;
    downloadProgress: number | null;
    onDownload: (model: OfflineModel) => void;
    onUninstall: (model: OfflineModel) => void;
}> = ({ model, isDownloaded, downloadProgress, onDownload, onUninstall }) => {
    const isDownloading = downloadProgress !== null;
    return (
        <div className="bg-white dark:bg-[#202C33] p-4 rounded-lg shadow-md border border-gray-200 dark:border-gray-700">
            <div className="flex justify-between items-start">
                <div>
                    <h3 className="text-lg font-bold text-gray-800 dark:text-gray-200">{model.name}</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">v{model.version} | {model.size} | {model.compatibility}</p>
                </div>
                {model.isRecommended && <span className="text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 font-semibold px-2 py-1 rounded-full">Recommended</span>}
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300 my-2">{model.description}</p>
            {isDownloading ? (
                <div>
                    <p className="text-sm text-blue-600 dark:text-blue-400">Downloading... {downloadProgress}%</p>
                    <ProgressBar progress={downloadProgress!} />
                </div>
            ) : isDownloaded ? (
                <button onClick={() => onUninstall(model)} className="w-full text-sm bg-red-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-red-600 transition-colors">
                    Uninstall
                </button>
            ) : (
                <button onClick={() => onDownload(model)} className="w-full text-sm bg-blue-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors">
                    Download
                </button>
            )}
        </div>
    );
};

const ModelHub: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    downloadedModels: Set<string>;
    onDownload: (model: OfflineModel) => void;
    onUninstall: (model: OfflineModel) => void;
}> = ({ isOpen, onClose, downloadedModels, onDownload, onUninstall }) => {
    const [downloadsInProgress, setDownloadsInProgress] = useState<Record<string, number>>({});
    
    if (!isOpen) return null;

    const handleDownload = (model: OfflineModel) => {
        const modelId = model.id;
        setDownloadsInProgress(prev => ({ ...prev, [modelId]: 0 }));
        const interval = setInterval(() => {
            setDownloadsInProgress(prev => {
                const newProgress = (prev[modelId] ?? 0) + 10;
                if (newProgress >= 100) {
                    clearInterval(interval);
                    onDownload(model);
                    const { [modelId]: _, ...rest } = prev;
                    return rest;
                }
                return { ...prev, [modelId]: newProgress };
            });
        }, 200);
    };

    const categories = [...new Set(OFFLINE_MODELS.map(m => m.category))];

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center" onClick={onClose}>
            <div className="bg-gray-100 dark:bg-[#111B21] rounded-lg shadow-2xl w-full max-w-2xl h-[90vh] flex flex-col animate-fade-in" onClick={e => e.stopPropagation()}>
                <header className="p-4 border-b dark:border-gray-700 bg-white dark:bg-[#202C33] rounded-t-lg flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200">Offline Model Hub</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200"><Icons.Close/></button>
                </header>
                <main className="flex-1 p-4 overflow-y-auto space-y-6">
                    {categories.map(category => (
                        <section key={category}>
                            <h3 className="text-xl font-semibold text-gray-700 dark:text-gray-300 mb-3 border-b-2 border-gray-300 dark:border-gray-600 pb-1">{category} Models</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {OFFLINE_MODELS.filter(m => m.category === category).map(model => (
                                    <ModelCard 
                                        key={model.id} 
                                        model={model}
                                        isDownloaded={downloadedModels.has(model.id)}
                                        downloadProgress={downloadsInProgress[model.id] ?? null}
                                        onDownload={handleDownload}
                                        onUninstall={onUninstall}
                                    />
                                ))}
                            </div>
                        </section>
                    ))}
                </main>
            </div>
        </div>
    )
};

const ImageHistoryModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    images: GeneratedImage[];
    onDelete: (id: string) => void;
}> = ({ isOpen, onClose, images, onDelete }) => {
    if (!isOpen) return null;

    const handleDownload = (img: GeneratedImage) => {
        const link = document.createElement('a');
        link.href = img.imageUrl;
        link.download = `friday-image-${img.id}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center" onClick={onClose}>
            <div className="bg-gray-100 dark:bg-[#111B21] rounded-lg shadow-2xl w-full max-w-4xl h-[90vh] flex flex-col animate-fade-in" onClick={e => e.stopPropagation()}>
                <header className="p-4 border-b dark:border-gray-700 bg-white dark:bg-[#202C33] rounded-t-lg flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200">Generated Image History</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200"><Icons.Close/></button>
                </header>
                <main className="flex-1 p-4 overflow-y-auto">
                    {images.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-full text-gray-500 dark:text-gray-400">
                            <Icons.Image />
                            <p className="mt-2 text-lg">No images generated yet.</p>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {images.map(img => (
                                <div key={img.id} className="bg-white dark:bg-[#202C33] rounded-lg shadow overflow-hidden border border-gray-200 dark:border-gray-700 flex flex-col">
                                    <div className="aspect-square w-full overflow-hidden bg-gray-200 dark:bg-gray-800 relative group">
                                         <img src={img.imageUrl} alt={img.prompt} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                                    </div>
                                    <div className="p-3 flex flex-col flex-1">
                                        <p className="text-sm text-gray-800 dark:text-gray-200 line-clamp-2 mb-2 flex-1" title={img.prompt}>{img.prompt}</p>
                                        <div className="flex justify-between items-center mt-2 border-t pt-2 border-gray-100 dark:border-gray-700">
                                            <span className="text-xs text-gray-500 dark:text-gray-400">{img.timestamp}</span>
                                            <div className="flex space-x-2">
                                                <button onClick={() => handleDownload(img)} className="p-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-full" title="Download">
                                                    <Icons.Download />
                                                </button>
                                                <button onClick={() => onDelete(img.id)} className="p-1.5 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-full" title="Delete">
                                                    <Icons.Trash />
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
};

const OverflowMenu: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onOpenSettings: () => void;
    onOpenModelHub: () => void;
    onOpenImageHistory: () => void;
    onExportChat: () => void;
    onClearChat: () => void;
}> = ({ isOpen, onClose, onOpenSettings, onOpenModelHub, onOpenImageHistory, onExportChat, onClearChat }) => {
    if (!isOpen) return null;

    const menuItems = [
        { label: "Settings", icon: <Icons.Settings />, action: onOpenSettings },
        { label: "Model Hub", icon: <Icons.ModelHub />, action: onOpenModelHub },
        { label: "Image Gallery", icon: <Icons.Gallery />, action: onOpenImageHistory },
        { label: "Export Chat", icon: <Icons.ExportChat />, action: onExportChat },
        { label: "Clear Chat", icon: <Icons.ClearChat />, action: onClearChat },
    ];
    return (
        <div className="fixed inset-0 z-40" onClick={onClose}>
            <div className="absolute top-16 right-2 bg-white dark:bg-[#202C33] rounded-md shadow-lg w-56 py-2 animate-fade-in-fast">
                <ul>
                    {menuItems.map(item => (
                        <li key={item.label}>
                            <button onClick={item.action} className="w-full text-left px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-[#111B21] flex items-center space-x-3">
                                {item.icon}
                                <span>{item.label}</span>
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    )
}

const ToggleSwitch: React.FC<{ checked: boolean; onChange: (checked: boolean) => void; }> = ({ checked, onChange }) => (
    <div
        onClick={() => onChange(!checked)}
        className={`w-12 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${checked ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'}`}
    >
        <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${checked ? 'translate-x-6' : ''}`} />
    </div>
);

const Settings: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    forceOffline: boolean;
    setForceOffline: (value: boolean) => void;
    onClearChat: () => void;
}> = ({ isOpen, onClose, forceOffline, setForceOffline, onClearChat }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center" onClick={onClose}>
            <div className="bg-gray-100 dark:bg-[#111B21] rounded-lg shadow-2xl w-full max-w-2xl h-[90vh] flex flex-col animate-fade-in" onClick={e => e.stopPropagation()}>
                <header className="p-4 border-b dark:border-gray-700 bg-white dark:bg-[#202C33] rounded-t-lg flex justify-between items-center">
                    <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200">Settings</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200"><Icons.Close/></button>
                </header>
                <main className="flex-1 p-6 overflow-y-auto space-y-8">
                    <section>
                        <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-4">Privacy Controls</h3>
                        <div className="bg-white dark:bg-[#202C33] p-4 rounded-lg">
                            <div className="flex justify-between items-center">
                                <div>
                                    <h4 className="font-semibold text-gray-800 dark:text-gray-200">Force Offline Mode</h4>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Simulate being offline, even with an internet connection.</p>
                                </div>
                                <ToggleSwitch checked={forceOffline} onChange={setForceOffline} />
                            </div>
                        </div>
                    </section>
                    <section>
                        <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-4">Data Management</h3>
                        <div className="bg-white dark:bg-[#202C33] p-4 rounded-lg">
                            <div className="flex justify-between items-center">
                                <div>
                                    <h4 className="font-semibold text-gray-800 dark:text-gray-200">Clear Chat History</h4>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Permanently delete the current conversation.</p>
                                </div>
                                <button onClick={onClearChat} className="text-sm bg-red-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-red-600 transition-colors">
                                    Clear
                                </button>
                            </div>
                        </div>
                    </section>
                </main>
            </div>
        </div>
    )
};


// --- MAIN APP --- //

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(UserService.loadState);
  
  const [currentMode, setCurrentMode] = useState<AppMode>(AppMode.Chat);
  const [isLoading, setIsLoading] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  
  // UI states
  const [isModelHubOpen, setIsModelHubOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isImageHistoryOpen, setIsImageHistoryOpen] = useState(false);
  const [isOverflowMenuOpen, setIsOverflowMenuOpen] = useState(false);
  
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  // Derived state from appState
  const { settings, chatHistory, downloadedModels: downloadedModelIds, imageHistory } = appState;
  const downloadedModels = new Set(downloadedModelIds);
  const { theme, forceOffline } = settings;

  useEffect(() => {
    UserService.saveState(appState);
  }, [appState]);


  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);


  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
    }
  }, []);

  const updateState = (updater: (prevState: AppState) => AppState) => {
    setAppState(updater);
  };

  const addMessage = (message: Omit<ChatMessage, 'id' | 'timestamp'>) => {
    const newMessage = {
        ...message,
        id: `msg-${Date.now()}-${Math.random()}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    updateState(prev => ({
        ...prev,
        chatHistory: [...prev.chatHistory, newMessage]
    }));
  };
  
  const toggleTheme = () => {
    updateState(prev => ({
      ...prev,
      settings: {
        ...prev.settings,
        theme: prev.settings.theme === 'light' ? 'dark' : 'light'
      }
    }));
  };

  const setForceOffline = (value: boolean) => {
    updateState(prev => ({
      ...prev,
      settings: { ...prev.settings, forceOffline: value }
    }));
  };

  const startListening = () => {
    if (!('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
        addMessage({ sender: Sender.AI, type: MessageType.Error, text: "Sorry, your browser doesn't support speech recognition." });
        return;
    }
    
    // Safety check to avoid double start
    if (isListening) return;

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognitionRef.current = new SpeechRecognition();
    recognitionRef.current.continuous = true;
    recognitionRef.current.interimResults = true;
    recognitionRef.current.lang = 'en-US';

    recognitionRef.current.onstart = () => {
        setIsListening(true);
    };

    recognitionRef.current.onend = () => {
        setIsListening(false);
    };

    recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        if (event.error !== 'aborted' && event.error !== 'no-speech') {
             addMessage({ sender: Sender.AI, type: MessageType.Error, text: `Speech recognition error: ${event.error}` });
        }
        setIsListening(false);
    };

    recognitionRef.current.onresult = (event) => {
        const transcript = Array.from(event.results)
            .map(result => result[0])
            .map(result => result.transcript)
            .join('');
        setInputText(transcript);
    };
    
    try {
        recognitionRef.current.start();
    } catch (e) {
        console.error("Speech recognition start failed:", e);
    }
  };

  const stopListening = () => {
      if (recognitionRef.current) {
          try {
            recognitionRef.current.stop();
          } catch (e) {
              console.error("Speech recognition stop failed:", e);
          }
      }
  };

  const handleDownloadModel = (model: OfflineModel) => {
      updateState(prev => ({
          ...prev,
          downloadedModels: Array.from(new Set([...prev.downloadedModels, model.id]))
      }));
      addMessage({
          sender: Sender.AI,
          type: MessageType.Text,
          text: `Model '${model.name}' installed. ${model.category} Mode is now available offline.`
      })
  };

  const handleUninstallModel = (model: OfflineModel) => {
    updateState(prev => ({
        ...prev,
        downloadedModels: prev.downloadedModels.filter(id => id !== model.id)
    }));
  };
  
  const handleDeleteImage = (id: string) => {
      updateState(prev => ({
          ...prev,
          imageHistory: prev.imageHistory.filter(img => img.id !== id)
      }));
  };

  const handleClearChat = () => {
    updateState(prev => ({
        ...prev,
        chatHistory: [STARTUP_MESSAGE]
    }));
    setIsOverflowMenuOpen(false);
    setIsSettingsOpen(false);
  };
  
  const handleExportChat = () => {
      const chatContent = chatHistory
          .map(msg => `[${msg.timestamp}] ${msg.sender === 'user' ? 'You' : 'Friday'}:\n${msg.text}\n`)
          .join('\n');
      const blob = new Blob([chatContent], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `friday-chat-${new Date().toISOString().slice(0, 10)}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      setIsOverflowMenuOpen(false);
  };
  
  const handleSend = useCallback(async (text: string, file?: File) => {
    if (isListening && recognitionRef.current) {
        recognitionRef.current.stop();
    }
    if (!text && !file) return;

    if (file && currentMode !== AppMode.ImageAnalysis && currentMode !== AppMode.ImageGen) {
        addMessage({ sender: Sender.AI, type: MessageType.Error, text: 'You can only attach images in Image Analysis or Image Generation (editing) mode.' });
        return;
    }
    
    addMessage({ sender: Sender.User, type: MessageType.Text, text: text || (currentMode === AppMode.ImageAnalysis ? `Analyzing image...` : `Processing image...`) });
    setIsLoading(true);

    const effectiveIsOffline = isOffline || forceOffline;

    // --- ENHANCED OFFLINE LOGIC ---
    if (effectiveIsOffline) {
        if (currentMode === AppMode.Search) {
            addMessage({
                sender: Sender.AI,
                type: MessageType.Error,
                text: "Search mode requires an internet connection and is unavailable offline."
            });
            setIsLoading(false);
            return;
        }

        const modelForMode = OFFLINE_MODELS.find(m => m.category === currentMode);
        if (modelForMode && downloadedModels.has(modelForMode.id)) {
            // Simulate offline processing time
            setTimeout(() => {
                const offlineResponse = `(Offline response) Friday processed your request for "${text}" using the ${modelForMode.name} model.`;
                if (currentMode === AppMode.ImageGen) {
                     // In a real offline scenario, we might generate a placeholder or low-res pattern
                     addMessage({ sender: Sender.AI, type: MessageType.Text, text: offlineResponse });
                } else {
                     addMessage({ sender: Sender.AI, type: MessageType.Text, text: offlineResponse });
                }
                setIsLoading(false);
            }, 1000);
            return;
        } else {
            addMessage({
                sender: Sender.AI,
                type: MessageType.Error,
                text: `You're offline. This feature requires a downloaded model. Please connect to the internet or open the Model Hub to download one.`
            });
            setIsLoading(false);
            return;
        }
    }

    // --- ONLINE LOGIC ---
    try {
      let response;
      switch (currentMode) {
        case AppMode.Chat:
        case AppMode.Audio:
        case AppMode.Task:
          // Pass currentMode to allow handling Thinking/Task mode differently
          response = await GeminiService.generateChatResponse(text, currentMode);
          addMessage({ sender: Sender.AI, type: MessageType.Text, text: response });
          break;
        case AppMode.Search:
          response = await GeminiService.generateSearchResponse(text);
          addMessage({ sender: Sender.AI, type: MessageType.Text, text: response.text, citations: response.citations });
          break;
        case AppMode.ImageGen:
            let imageBase64;
            let mimeType;
            if (file) {
                imageBase64 = await fileToBase64(file);
                mimeType = getMimeType(file);
            }
          response = await GeminiService.generateImage(text, imageBase64, mimeType);
          const newImage: GeneratedImage = {
              id: `img-${Date.now()}`,
              prompt: text,
              imageUrl: response,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          };
          updateState(prev => ({
              ...prev,
              imageHistory: [newImage, ...prev.imageHistory]
          }));
          addMessage({ sender: Sender.AI, type: MessageType.Image, text: `Here is the image you requested: "${text}"`, imageUrl: response });
          break;
        case AppMode.ImageAnalysis:
          if (!file) {
            throw new Error('Please select an image for analysis.');
          }
          const base64 = await fileToBase64(file);
          const mime = getMimeType(file);
          response = await GeminiService.analyzeImage(text, base64, mime);
          addMessage({ sender: Sender.AI, type: MessageType.Text, text: response });
          break;
      }
    } catch (error) {
      console.error('API Error:', error);
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
      addMessage({ sender: Sender.AI, type: MessageType.Error, text: `Sorry, I ran into an issue: ${errorMessage}` });
    } finally {
      setIsLoading(false);
    }
  }, [currentMode, isOffline, downloadedModels, isListening, forceOffline, addMessage]);

  useEffect(() => {
    if (isLoading) {
      const loadingMessage: ChatMessage = {
        id: `loading-${Date.now()}`,
        sender: Sender.AI,
        type: MessageType.Loading,
        text: '',
        timestamp: '',
      };
      updateState(p => ({...p, chatHistory: [...p.chatHistory, loadingMessage]}));
    } else {
      updateState(p => ({...p, chatHistory: p.chatHistory.filter(m => m.type !== MessageType.Loading)}));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoading]);
  
  const effectiveIsOffline = isOffline || forceOffline;

  return (
    <div className="h-screen w-screen flex flex-col font-sans max-w-4xl mx-auto bg-[#ECE5DD] dark:bg-[#111B21] shadow-2xl">
      <Header 
        mode={currentMode} 
        isOffline={effectiveIsOffline} 
        theme={theme}
        toggleTheme={toggleTheme}
        onMenuClick={() => setIsOverflowMenuOpen(true)}
      />
      <ChatWindow messages={chatHistory} />
      <MessageInput 
        onSend={handleSend} 
        mode={currentMode} 
        isLoading={isLoading} 
        isListening={isListening} 
        onStartListening={startListening}
        onStopListening={stopListening}
        text={inputText}
        setText={setInputText}
        />
      <ModeSelector currentMode={currentMode} onModeChange={setCurrentMode} isOffline={effectiveIsOffline} downloadedModels={downloadedModels} />
      <ModelHub 
        isOpen={isModelHubOpen}
        onClose={() => setIsModelHubOpen(false)}
        downloadedModels={downloadedModels}
        onDownload={handleDownloadModel}
        onUninstall={handleUninstallModel}
      />
      <ImageHistoryModal
        isOpen={isImageHistoryOpen}
        onClose={() => setIsImageHistoryOpen(false)}
        images={imageHistory}
        onDelete={handleDeleteImage}
      />
      <Settings
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        forceOffline={forceOffline}
        setForceOffline={setForceOffline}
        onClearChat={handleClearChat}
      />
      <OverflowMenu 
        isOpen={isOverflowMenuOpen}
        onClose={() => setIsOverflowMenuOpen(false)}
        onOpenSettings={() => { setIsSettingsOpen(true); setIsOverflowMenuOpen(false); }}
        onOpenModelHub={() => { setIsModelHubOpen(true); setIsOverflowMenuOpen(false); }}
        onOpenImageHistory={() => { setIsImageHistoryOpen(true); setIsOverflowMenuOpen(false); }}
        onExportChat={handleExportChat}
        onClearChat={handleClearChat}
      />
    </div>
  );
};

export default App;
